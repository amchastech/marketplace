let products = [
 {id:"1", title:"Crop Top", price:12.99},
 {id:"2", title:"Jeans", price:29.99}
];

export async function GET(){
  return Response.json(products);
}
