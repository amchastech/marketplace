export default async function Page(){
  const res = await fetch("http://localhost:3000/api/products",{cache:"no-store"});
  const data = await res.json();

  return (
    <main style={{padding:20,fontFamily:"sans-serif"}}>
      <h1>Marketplace (Vercel Ready)</h1>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        {data.map(p=>(
          <div key={p.id} style={{border:"1px solid #ddd",padding:10}}>
            <h3>{p.title}</h3>
            <p>${p.price}</p>
          </div>
        ))}
      </div>
    </main>
  )
}
